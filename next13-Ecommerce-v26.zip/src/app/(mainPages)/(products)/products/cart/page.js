


import ShowCartCall from '@/app/components/cliants/ShowCart/ShowCartCall'
import React from 'react'

const Cart = async () => {

  // const productsJSONObjectFS = await getAllProductsData();
  // const productsArrayFS = productsJSONObjectFS.products;

  return (
    <>


      <ShowCartCall></ShowCartCall>



    </>
  )
}

export default Cart