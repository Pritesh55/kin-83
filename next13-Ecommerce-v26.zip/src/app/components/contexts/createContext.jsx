'use client';
import { createContext } from "react";

// Context API 02 :: createContext ::
// :: create and Export createContext hook....
export const CartProductsContext = createContext();