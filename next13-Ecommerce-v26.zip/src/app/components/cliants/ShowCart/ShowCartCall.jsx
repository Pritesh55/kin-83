'use client';
import React from 'react'
import ShowCart from './ShowCart';

const ShowCartCall = () => {
  return (
    <ShowCart></ShowCart>
  )
}

export default ShowCartCall