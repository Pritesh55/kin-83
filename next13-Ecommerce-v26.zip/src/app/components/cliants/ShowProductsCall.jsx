'use client';
import React from 'react'
import ShowProducts from './ShowProducts';




const ShowProductsCall = async () => {

    return (
        <>
            <ShowProducts></ShowProducts>
        </>
    )
}

export default ShowProductsCall